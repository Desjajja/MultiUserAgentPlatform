---
name: standard-demo
description: Fixed-response QA demo skill for creating deterministic question/answer pairs. Use when the user wants a demo that must return exact predefined answers verbatim, with no paraphrasing, summarization, or modification.
---

# Standard Demo

## Purpose

Use this skill to serve a small fixed QA demo. When a user message matches one of the predefined triggers, return the stored answer **exactly as written**.

## Behavior

- Match the incoming message to a fixed QA pair.
- Return the answer verbatim.
- Keep any large titles and small titles in black bold Markdown form (`**...**`).
- Do not rewrite, shorten, expand, or “improve” the response.
- If multiple triggers match, choose the most specific one.
- If nothing matches, use the fallback response.

## How to respond

1. Read the trigger text.
2. Find the best match in `references/qa-mapping.md`.
3. Output the answer block exactly.
4. Preserve line breaks, punctuation, bullets, and emoji.

## Reference source

See `references/qa-mapping.md` for the full trigger → answer mapping.

## Simulated detection template

When the user says `模拟检测`, return the fixed PPE alert template from `references/qa-mapping.md` and attach the saved reference image at:

`assets/simulated-ppe-reference.jpg`

Record each sent image in `references/send-log.md`.
Do not alter the wording or the image.

## Quality bar

This skill is only correct if the response is stable across runs.
If a response would vary, do not generate it dynamically; use the fixed mapping instead.
