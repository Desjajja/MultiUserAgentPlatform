# Standard Demo QA Mapping

Use these exact trigger → response pairs. Do not paraphrase, summarize, or add extra content.

## Rules
- Match by intent and key phrase.
- If multiple triggers are present, prefer the most specific one.
- Return the stored answer verbatim.
- If nothing matches, reply with a short fallback asking for a fixed demo question.

## Fixed QA pairs

### 1. Greeting
**Trigger:** `你好`

**Answer:**
```text
**你好，徐泽军！有什么需要？**
```

### 2. Start work / opening report
**Trigger:** `开始今天的工作`

**Answer:**
```text
收到。
从现在起，我按这个职责工作：
1. 每天整理热点并给出行动建议
2. 实验前拆解任务、生成 SOP、监控执行
3. 操作软件：调模型、总结对话、生成报告 / 实验卡片
4. 操作物理世界：底盘搬运 / 抓取、双臂移液及抓取
5. 同步记录：视频、曲线、动作日志、异常
6. 傍晚整理日志并生成飞书日报
你直接下指令，我按这个模式执行。
```

### 3. Openwork report
**Trigger:** `小环开工报告`

**Answer:**
```text
✅ 所有硬件模块自检通过，状态良好。
待办任务
- 检查离子色谱仪气阀状态
- 整理今日实验记录
- 生成日报
```

### 4. Hotspot sorting request
**Trigger:** `帮我整理一下今天的科研热点，并将与我们相关的记录到 RAG 数据库中`

**Answer:**
```text
已整理好相关热点，并上传到数据库中。
今日热点
- 碳排放核算与碳足迹管理：记录实验和设备运行过程中的能耗，便于后续做绿色实验评估。
- CO₂ 资源化利用：关注二氧化碳在吸收、转化和反应调控中的应用。
- 水污染治理与离子选择性去除：聚焦高镁卤水、重金属和盐湖体系中的选择性分离。
- 环境传感与在线监测：关注 pH、温度、电导、流量等参数的实时反馈。
- 绿色实验自动化：通过机器人和自动记录减少人工误差、试剂浪费和重复劳动。
命名
- RAG_ENV_HOTSPOT_2026-03-22，已上传。
```

### 5. Lithium extraction routes
**Trigger:** `给出实验提取锂的三种可行路线`

**Answer:**
```text
**三种可行路线**

**1. LDH 选择性吸附路线**
以 Li-Al LDH 为吸附剂，利用层间离子交换实现对 Li⁺ 的选择性富集，适合做动力学和选择性评估。

**2. 卤水调控 + pH 反馈路线**
通过调节溶液 pH、离子强度和 CO₂ 条件，控制 Li⁺ 的富集与分离过程，适合做在线反馈验证。

**3. 对照验证路线**
以常规盐湖/卤水体系作为基线，对比不同搅拌、温度、配比条件下的提锂效果，适合做方法学对照。
```

### 6. Route selection + SOP
**Trigger:** `我选路线1，帮我生成一份实验卡片和 SOP`

**Answer:**
```text
实验卡片与 SOP
实验卡片
- 项目：Li-Al LDH 吸附提锂
- 路线：R1 选择性吸附路线
- 目标：验证 Li⁺ 在 LDH 体系中的富集效果、选择性表现和动力学特征
- 关键变量：pH、搅拌速度、温度、初始浓度
- 输出：吸附曲线、动力学参数、异常记录
- 已记录在实验档案中
SOP
1. 物料准备
准备 Li-Al LDH、标准溶液、离心管、移液耗材及记录表。
2. 仪器自检
检查 pH 计、搅拌装置、离心机和相关联动设备状态。
3. 搬运与布置
将实验耗材搬运至操作台，按顺序摆放，完成基础布置。
4. 预处理与初始采集
对样品进行预处理，记录初始条件并采集基线数据。
5. 定时取样
按设定间隔进行多次取样，记录时间点和样品编号。
6. 样品转移离心
将样品转入离心流程，确认配重对称后开始操作。
7. 结果记录与异常检查
检查曲线变化、重吸事件、气泡情况及其他异常。
8. 数据归档
整理日志、曲线和图片，统一归档到实验档案。
以上方案是否可行？确认后我将进入监控模式。
```

### 7. Delivery task
**Trigger:** `先将董航老师的包送到他的办公室里`

**Answer:**
```text
📍 机器人确认到达董航老师办公室
🧾 动作日志：路径完成，物品已送达
📸 送达照片已存档
```

### 8. Enable experiment mode
**Trigger:** `好的，现在开启实验模式`

**Answer:**
```text
⚙️ 开启实验模式
✅ 实验模式已开启。
📡 监控模式已同步开启
将持续监控：
- 实验执行状态
- 操作规范
- 任务执行进度
🧭 指令注入说明
现在实验人员发出的指令将自动注入到我的执行队列。
发送“关闭实验模式”可随时退出。
```

### 9. Start package delivery
**Trigger:** `开始执行【包裹送达】`

**Answer:**
```text
📍 机器人确认已送达董航老师办公室
🧾 动作日志：任务完成
```

### 10. Re-enable experiment mode
**Trigger:** `好的，现在开启实验模式`

**Answer:**
```text
⚙️ 开启实验模式
✅ 实验模式已开启。
📡 监控模式已同步开启
将持续监控：
- 实验执行状态
- 操作规范
- 任务执行进度
🧭 指令注入说明
现在实验人员发出的指令将自动注入到我的执行队列。
发送“关闭实验模式”可随时退出。
```

## 11. Simulated detection
**Trigger:** `模拟检测`

**Answer:**
```text
⛔ 【安全警告·爆红】未检测到实验服穿戴

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔴 严重级别：RED — 实验操作已自动暂停
📷 证据截图：见下图
📋 实验编号：EXP-CO2-Li-0002
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

必须穿戴：
  🥼 实验服 / Lab Coat 

⚠️ 机器人执行单元已挂起，SOP 停留在当前步骤。

穿戴完毕后回复：
👉 「PPE OK」  ← 系统自动解除暂停，SOP从当前步骤继续推进
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Image:** `assets/simulated-ppe-reference.jpg`

### 12. PPE confirmation
**Trigger:** `PPE OK`

**Answer:**
```text
PPE 已确认，解除暂停。
可以继续从当前步骤推进。
```

### 13. Start experiment mode
**Trigger:** `开始实验模式`

**Answer:**
```text
⚙️ 开启实验模式
✅ 实验模式已开启。
🧭 指令注入说明
现在实验人员发出的指令将自动注入到我的执行队列。
发送“关闭实验模式”可随时退出。
```

### 14. Check centrifuge tube placement
**Trigger:** `检测一下是否在放置离心管`

**Answer:**
```text
🧪 已检测到正在摆放离心管。
📸 参考图已附上，请核对当前动作与现场状态。
```

**Image:** `assets/placing-centrifuge-tubes.jpg`

### 15. Pipetting task orchestration
**Trigger:** `从烧杯中取样，然后从上到下，从左到右依次排空至桌面上的6支试管，最后留样至离心管中`

**Answer:**
```text
已收到指令：从烧杯中取样，然后从上到下，从左到右依次排空至桌面上的6支试管，最后留样至离心管中留样。🤖✨

| 项目 | 内容 |
|---|---|
| 任务 | 从烧杯中取样至桌面上的 6 支试管 |
| 顺序 | 从上到下、从左到右 |
| 执行状态 | 机械臂均已连接 |
| 当前准备 | 执行环境就绪 |

机械臂均已连接，执行环境就绪。🧠⚙️
```

## Fallback
If the incoming message does not match any fixed QA pair:
```text
请发送一个已定义的固定 demo 问题，我会按原样返回对应答案。
```
